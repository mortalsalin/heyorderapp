export const config = {
  apiKey: "<enter your key here>",
  authDomain: "<enter your key here>",
  databaseURL: "<enter your key here>",
  projectId: "<enter your key here>",
  storageBucket: "<enter your key here>",
  messagingSenderId: "<enter your key here>"
};

export const mapKey = '<enter your key here>';

export const pushAuthKey = '<enter your key here>';

