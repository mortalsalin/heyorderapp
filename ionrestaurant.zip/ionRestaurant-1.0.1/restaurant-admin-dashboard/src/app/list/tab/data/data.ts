export class UserProfile {
    constructor(
    public email?: string,
    public name?: number
    ) {  }
}