export class Restaurant {
    constructor(
    public description?: string,
    public name?: string,
    public show?: boolean,
    public type?: string,
    public total?: string,
    public imgBg?: string
    ) {  }
}
